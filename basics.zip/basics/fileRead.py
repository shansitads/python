
myFile = open("fileToUse.txt", "r")
'''
First parameter: You can write file name or path
Second parameter:
    "r" - read
    "w" - write (modify/add content)
"   a" - append (add information but not modify existing content)
    "r+" - read and write
'''

'''
myFile.readable() -
    It is good practice to check if file is readable. 
    The file will be readable if it was opened with "r" or "r+".
myFile.read() -
    Reads all the contents of the file at once.
myFile.readline() -
    Reads the file line by line. If you write this statement twice, the next line will be read the second time.
myFile.readlines() -
    Makes an array in which each line of the file is a separate element.
'''

for student in myFile.readlines():
    print(student, end="")

myFile.close()
# always remember to close the file

