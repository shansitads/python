board3 = float(input("Enter predicted top 3 average, out of 80: ")) #out of 80
bioInternal20 = 20 #out of 20
geoInternal20 = 20 #out of 20
hinInternal20 = 20 #out of 20
compInternal100 = 100 #out of 100


def roundScore(s):
    return int(100*s)/100

bio = roundScore((0.7*board3*100/80 + 0.3*bioInternal20*100/20)*0.8+bioInternal20)
geo = roundScore((0.7*board3*100/80 + 0.3*geoInternal20*100/20)*0.8+geoInternal20)
hin = roundScore((0.7*board3*100/80 + 0.3*hinInternal20*100/20)*0.8+hinInternal20)
comp = roundScore((0.7*(board3*100/80)*1 + 0.3*compInternal100*1 + compInternal100)/2)

print("geo = "+str(bio))
print("bio = "+str(geo))
print("hindi = "+str(hin))
print("comp = "+str(comp))
