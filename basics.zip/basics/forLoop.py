
for i in range(1, 10):#range from 1 to 9 (exclusive of upper bound)
    print(i)

print()
str = "Hello"
for letter in str:
    print(letter)

print()
arr = [1, 2, 3, 4, 5, 6]
for n in arr:
    print(n)