'''
Tupples are immutable. They are similar to lists, but their values cannot be changed. In practical use, use tupples for fixed values such as coordinates
'''
coordinates = (4, 5)
print(coordinates)
print(coordinates[0])
print(coordinates[1])
