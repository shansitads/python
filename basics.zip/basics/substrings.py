name = "Shansita"

print(name[0:3]) # 0 to 2
print(name[-3]) # 3rd character from the back
print(name[-3:]) # 3rd from the back till end
print(name[:6]) # start till 5

print(name[2:4])
print(name[-6:-3]) # [-3:-5] will not be valid as you must go in left to right order
print(name[2:-3])