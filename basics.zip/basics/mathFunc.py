#import math 'module'
from math import*

n = 5
f = 2.3
print(2**3) # 2^3
print(ceil(f))
print(floor(f))
print(pow(n, 2))
print(sqrt(n))
print(abs(-5))
print(max(n, f))
print(min(n, f))
print(round(f))