colour = input("Enter a colour: ")
plural_noun = input("Enter a plural noun: ")
celebrity = input("Enter the name of a celebrity: ")
fruit = input("Enter a fruit: ")

print("\nroses are "+colour)
print(plural_noun + " are blue")
print(celebrity + " likes " + fruit)
print("snd so do you ")