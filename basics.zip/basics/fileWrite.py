myFile = open("fileToUse.txt", "r")
toFile = open("fileToWriteTo.txt", "w") #This creates new file if it doesnt exist.
toFile.write("Hello")
'''
Write clears out all existing data in the file and then writes the new data.
'''