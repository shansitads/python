myFile = open("fileToUse.txt", "a")
myFile.write("Irene 75\n")
myFile.close()